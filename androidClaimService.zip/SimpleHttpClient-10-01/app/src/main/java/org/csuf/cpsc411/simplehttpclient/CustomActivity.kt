package org.csuf.cpsc411.simplehttpclient

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import kotlinx.android.synthetic.main.main_activity.*
import java.util.*

open class CustomActivity : AppCompatActivity() {
    lateinit var cList : MutableList<Claim>
    lateinit var cService : ClaimService

    fun refreshScreen(cObj : Claim) {
        //
        Log.d("Person Service", "Refreshing the Screen. ")
        val claimTitle : EditText = findViewById(R.id.claimTitle)
        val date : EditText = findViewById(R.id.date)
        //
        claimTitle.setText(cObj.title)
        claimTitle.setEnabled(false)
        date.setText(cObj.date)
        val nBtn : Button = findViewById(R.id.add_btn_id)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val colGenerator = LableColumnGenerator(this)
        val colView = colGenerator.generate()
        val fldRowGenerator = ObjDetailScreenGenerator(this)
        val rowView = fldRowGenerator.generate()
        val status = StatusGenerator(this)
        val statusView = status.generate()
        //setContentView(colView)
        setContentView(rowView)
        val bView : Button = findViewById(R.id.add_btn_id)
        //
        //val bView : Button = findViewById(R.id.add_btn_id)
        //
        bView.setOnClickListener{
            Log.d("status", "made it here")
            // get the next Person object
            var id = UUID.randomUUID()
            var isSolved = false
            val cObj = Claim(id.toString(),claimTitle.text.toString(),date.text.toString(),isSolved)
            cService.addClaim(cObj)
            Log.d("status", "made it here")


        }
        //
        val pos = intent.getIntExtra("ElementId", 0)
        Log.d("Detailed Activity ", "Display ${pos} Person object")
        cService = ClaimService.getInstance(this)
        if (cService.claimList.count() != 0) {
            val pObj = cService.fetchAt(pos)
            refreshScreen(pObj)
        }


    }

}