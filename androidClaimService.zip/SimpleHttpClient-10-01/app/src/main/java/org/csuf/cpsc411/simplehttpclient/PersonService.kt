package org.csuf.cpsc411.simplehttpclient

import android.app.Activity
import android.content.Context
import android.util.Log
import android.widget.TextView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.AsyncHttpResponseHandler
import cz.msebera.android.httpclient.Header
import cz.msebera.android.httpclient.entity.StringEntity
import java.lang.reflect.Type

class ClaimService (val ctx : CustomActivity){
    lateinit var mClaim: Claim
    var claimList : MutableList<Claim> = mutableListOf()
    var currentIndx : Int = 0


    companion object {
        private var cService : ClaimService? = null

        fun getInstance(act : CustomActivity) : ClaimService {
            if (cService == null) {
                cService = ClaimService(act)
            }

            return cService!!
        }
    }



    fun fetchAt(e : Int) : Claim {
        currentIndx = e
        return claimList[currentIndx]
    }

    inner class addServiceRespHandler : AsyncHttpResponseHandler() {
        override fun onSuccess(
            statusCode: Int,
            headers: Array<out Header>?,
            responseBody: ByteArray?
        ) {
            val cView : TextView = ctx.findViewById(R.id.statusMessageVar)
            cView.text = "Claim ${mClaim.title} was successfully created."
        }

        override fun onFailure(
            statusCode: Int,
            headers: Array<out Header>?,
            responseBody: ByteArray?,
            error: Throwable?
        ) {
            val cView : TextView = ctx.findViewById(R.id.statusMessageVar)
            cView.text = "Claim ${mClaim.title} failed to be created."
            Log.d("status", "made it thy")
        }
    }

    fun addClaim(cObj : Claim) {
        val client = AsyncHttpClient()
        val requestUrl = "http://192.168.1.5:8090/ClaimService/add"
        // 1. Convert the pObj into JSON string
        val cJsonString= Gson().toJson(cObj)
        // 2. Send the post request
        val entity = StringEntity(cJsonString)
        mClaim = cObj
        // cxt is an Android Application Context object
        client.post(ctx, requestUrl, entity,"application/json", addServiceRespHandler())
    }


}